create view q8(travelerID,reciprocals ,backScratches ) as 
values(1001,1,1),(1000,0,0),(1002,0,0);

CREATE TABLE oracle_q8 AS 
select * from q8;
