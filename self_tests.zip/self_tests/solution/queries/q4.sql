create view q4(percentage) as values (67);

CREATE TABLE oracle_q4 AS 
select * from q4;
