SELECT * FROM Booking
WHERE listingId=3000 AND startDate='2016-10-05';
