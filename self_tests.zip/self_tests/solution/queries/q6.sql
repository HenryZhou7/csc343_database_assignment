create view q6(travelerID, surname, numListings) 
as values (1001, 'n2',2);

CREATE TABLE oracle_q6 AS 
select * from q6;
