create view q2(travelerId,name,email,mostRequestedCity,numRequests) as
values (1002, 'f3 n3', 'fn3@domain.com', 'c1', 12);

CREATE TABLE oracle_q2 AS 
select * from q2;
